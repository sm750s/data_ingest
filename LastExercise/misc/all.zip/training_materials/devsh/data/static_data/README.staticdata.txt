This folder contains static copies of processed data for use by the course catchup/advance
script to save time.  E.g. the output of sqoop imports, etc.  Students should not use this
data for exercises.
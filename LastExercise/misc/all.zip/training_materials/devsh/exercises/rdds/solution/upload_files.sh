hdfs dfs -put  $DEVDATA/frostroad.txt  /loudacre/
hdfs dfs -put  $DEVDATA/makes*.txt  /loudacre/

hdfs dfs -put  $DEVDATA/weblogs/  /loudacre/

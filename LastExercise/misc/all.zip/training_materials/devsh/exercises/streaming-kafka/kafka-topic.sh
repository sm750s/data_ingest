#!/bin/bash

kafka-topics --create --zookeeper master-1:2181 --replication-factor 1 --partitions 2 --topic weblogs

kafka-topics --list    --zookeeper master-1:2181

kafka-topics --describe weblogs    --zookeeper master-1:2181,master-2:2181,worker-2:2181

